ViewId = 1
CurrentSection = ""
creds = ""

isloggedin = False

rant_text = ""
rant_tags = ""